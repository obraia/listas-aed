package models;

public class Candidato {
    private String nome;
    private int numero;
    private String estado;
    private String municipio;
    private String partido;
    private char cargo;
    
    public Candidato() {}

    public Candidato(String nome, int numero,String estado, String municipio, String partido, char cargo) {
        this.nome = nome;
        this.numero = numero;
        this.estado = estado;
        this.municipio = municipio;
        this.partido = partido;
        this.cargo = cargo;
    }

    public String getNome() {
        return this.nome;
    }

    public int getNumero() {
        return this.numero;
    }
    
    public String getEstado(){
        return this.estado;
    }

    public String getMunicipio() {
        return this.municipio;
    }

    public String getPartido() {
        return this.partido;
    }

    public char getCargo() {
        return this.cargo;
    }

    @Override
    public String toString() {
        return String.format("%s;%s;%s;%s;%s", nome, numero, municipio, partido, cargo);
    }
}