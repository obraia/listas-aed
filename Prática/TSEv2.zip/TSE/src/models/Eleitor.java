package models;

public class Eleitor {
    
}