package models;

public class Municipio {

    private String nome;
    private String estado;
    private int habitantes;
    private int vereadores;

    public Municipio() {
    }

    public Municipio(String nome, String estado, int habitantes, int vereadores) {
        this.nome = nome;
        this.estado = estado;
        this.habitantes = habitantes;
        this.vereadores = vereadores;
    }

    public String getNome() {
        return this.nome;
    }

    public String getEstado() {
        return this.estado;
    }

    public int getHabitantes() {
        return this.habitantes;
    }
    
        public int getVereadores() {
        return this.vereadores;
    }

    @Override
    public String toString() {
        return String.format("[Municipio] nome: %s - estado: %s - habitantes: %s - vereadores: %s", this.nome, this.estado, this.habitantes, this.vereadores);
    }
}
