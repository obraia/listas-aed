package models;

public class Partido {
    private String nome;
    private String sigla;
    
    public Partido() {}
    
    public Partido(String nome, String sigla){
        this.nome = nome;
        this.sigla = sigla;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public String getSigla(){
        return this.sigla;
    }

    @Override
    public String toString() {
        return String.format("[Partido] nome: %s - sigla: %s", this.nome, this.sigla);
    }
}
