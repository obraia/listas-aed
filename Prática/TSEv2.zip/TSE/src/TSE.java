

import views.HomeFrame;

public class TSE {

    public static void main(String[] args) {
        HomeFrame homeFrame = new HomeFrame();
        homeFrame.show();
    }
}
