package controllers;

import utils.*;
import models.Urna;

public class UrnaController {
    
}