package controllers;

import utils.*;
import models.Municipio;

public class MunicipioController {
    
    public static ListaMunicipio listaMunicipio;
    
    public ListaMunicipio carregar(String caminhoArquivo) {
        listaMunicipio = new ListaMunicipio();
        
        Arquivo arquivo = new Arquivo(caminhoArquivo);
        
        String linha;
        
        while ((linha = arquivo.readLine()) != null) {
            String[] aux = linha.split(";");
            
            if(aux.length != 4) return null;
            
            String nome = aux[0];
            String estado = aux[1];
            int habitantes = Integer.parseInt(aux[2]);
            int vereadores = Integer.parseInt(aux[3]);
            
            listaMunicipio.inserirFinal(new Municipio(nome, estado, habitantes, vereadores));
        }
        
        return listaMunicipio;
    }
    
}
