package controllers;

import utils.*;
import models.Candidato;

public class CandidatoController {
        public static ListaCandidato listaCandidato;
    
    public ListaCandidato carregar(String caminhoArquivo) {
        listaCandidato = new ListaCandidato();
        
        Arquivo arquivo = new Arquivo(caminhoArquivo);
        
        String linha;
        
        while ((linha = arquivo.readLine()) != null) {
            String[] aux = linha.split(";");
            
            if(aux.length != 6) return null;
            
            String nome = aux[0];
            int numero = Integer.parseInt(aux[1]);
            String estado = aux[2];
            String municipio = aux[3];
            String partido = aux[4];
            char cargo = aux[5].charAt(0);
            
            listaCandidato.inserirFinal(new Candidato(nome, numero, estado, municipio, partido, cargo));
        }
        
        return listaCandidato;
    }
}