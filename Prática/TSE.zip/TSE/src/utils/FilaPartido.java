package utils;

import models.Partido;

public class FilaPartido {

    private CelulaPartido frente; // referência ao partido que está na frente da fila. Esse partido é utilizado
                                  // apenas para controle.
    private CelulaPartido tras; // referência ao partido que está na última posição da fila.

    // Construtor que cria uma fila vazia inicializando o partido da frente da fila
    // e os atributos de controle da fila (frente e tras).
    public FilaPartido() {
        CelulaPartido celula = new CelulaPartido();
        
        frente = celula;
        tras = celula;
    }

    // Verifica se a fila está vazia. Em caso afirmativo, retorna true e em caso
    // negativo retorna false.
    public Boolean filaVazia() {
        // Se a fila apresentar apenas o elemento de controle, ela está vazia.
        if (frente == tras) {
            return true;
        } else {
            return false;
        }
    }

    // Insere o item da fila partido, passado como parâmetro para esse método, no final
    // da fila.
    public void enfileirar(Partido partido) {
        // inserção do novo partido no final da fila.
        CelulaPartido auxCelula = new CelulaPartido();
        tras.proximo = auxCelula;
        
        auxCelula.item = partido;
        
        // atualização do atributo de controle tras.
        tras = tras.proximo;
        tras.item = partido;
    }

    // Retira o partido que ocupa a primeira posição da fila. Se a fila estiver
    // vazia, esse método deve retornar null; caso contrário, esse método deve
    // retornar o partido retirado da fila.
    public Partido desenfileirar() {

        CelulaPartido aux;
        Partido partido;

        if (!(filaVazia())) {
            // aux aponta para o partido da fila que será retornado/desenfileirado, ou seja,
            // o primeiro partido da fila.
            aux = frente.proximo;

            // atualização do primeiro partido da fila.
            frente.proximo = aux.proximo;

            partido = aux.item;
            aux.proximo = null;

            if (aux == tras)
                tras = frente;

            return (partido);
        }
        return null;
    }

    public Partido obterPrimeiro() {
        if (!filaVazia()) {
            return this.frente.proximo.item;
        } else {
            return null;
        }
    }

    public int obterNumeroPartidos() {
        CelulaPartido auxCelula = frente.proximo;
        
        int count = 0;
        
        while (auxCelula != null) {
            auxCelula = auxCelula.proximo;
            count++;
        }
        return count;
    }

    public void imprimir() {
        CelulaPartido auxCelula = frente.proximo;
        
        while (auxCelula != null) {
            System.out.println(auxCelula.item.toString());
            auxCelula = auxCelula.proximo;
        }
    }

    public void concatenar(FilaPartido fila) {
        while (!fila.filaVazia()) {
            this.enfileirar(fila.desenfileirar());
        }
    }


    public FilaPartido copiar() {
        FilaPartido copiaFila = new FilaPartido();
        CelulaPartido auxCelula = frente.proximo;
        Partido auxPartido;
        
        while (auxCelula != null) {
            auxPartido = auxCelula.item;    
            copiaFila.enfileirar(new Partido(auxPartido.getNome(), auxPartido.getSigla()));
            auxCelula = auxCelula.proximo;
        }
        return copiaFila;
    }
}