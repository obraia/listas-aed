package models;

public class Urna {
    
}