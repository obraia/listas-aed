package controllers;

import utils.*;
import models.Partido;

public class PartidoController {

    public static ListaPartido listaPartido;

    public ListaPartido carregar(String caminhoArquivo) {
        listaPartido = new ListaPartido();

        Arquivo arquivo = new Arquivo(caminhoArquivo);

        String linha;

        while ((linha = arquivo.readLine()) != null) {
            String[] aux = linha.split(";");
            
            String nome = aux[0];
            String sigla = aux[1];
            
            listaPartido.inserirFinal(new Partido(nome, sigla));    
        }
        
        return listaPartido;
    }
}
