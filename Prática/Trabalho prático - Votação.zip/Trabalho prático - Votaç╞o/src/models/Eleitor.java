package src.models;

public class Eleitor {
    
}