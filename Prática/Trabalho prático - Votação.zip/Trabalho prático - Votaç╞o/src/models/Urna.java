package src.models;

public class Urna {
    
}