package src.controllers;

public class PartidoController {
    
}