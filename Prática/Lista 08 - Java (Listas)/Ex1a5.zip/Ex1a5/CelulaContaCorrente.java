public class CelulaContaCorrente {

		ContaCorrente item;
		CelulaContaCorrente proximo;
		
		CelulaContaCorrente(){
			item = new ContaCorrente();
			proximo = null;
		}
}
